<?php
session_start();
require_once 'auth.php';
logoutAdmin();
?>