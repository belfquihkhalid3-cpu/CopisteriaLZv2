<?php
echo "GET params: ";
print_r($_GET);
echo "<br>URL: " . $_SERVER['REQUEST_URI'];
?>